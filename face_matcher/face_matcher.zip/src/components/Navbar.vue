<template>
  <nav class="navbar navbar-dark bg-black">
    <span class="navbar-brand mb-0 h1" style="  font-weight: bold;"
      >FACE RECOGNIZING</span
    >
  </nav>
</template>

<script>
export default {};
</script>

<style>
.bg-black {
  background-color: black;
}
</style>
